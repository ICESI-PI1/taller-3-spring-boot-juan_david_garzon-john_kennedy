package com.edu.icesi.taller3.security;

import lombok.Data;

@Data
public class AuthCredentials {
    private String userName;
    private String password;
    
}
